import java.util.*;

public class Main {
    // Athlete class used to model each participant
    public class Athlete {
        private int id;
        private int runTime;
        private int swimTime;
        private int difference;

        public Athlete(int id, int runTime, int swimTime) {
            this.id = id;
            this.runTime = runTime;
            this.swimTime = swimTime;
            this.difference = runTime - swimTime;
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) return true;
            else if (obj instanceof Athlete) {
                Athlete athlete = (Athlete) obj;
                return athlete.id == this.id;
            } else return false;
        }

        @Override
        public String toString() {
            return String.valueOf(id);
        }
    }

    private int n;
    private int run;
    private int swim;
    private int[] runTimes;
    private int[] swimTimes;

    public Main() {
        Scanner scan = new Scanner(System.in);
        this.n = scan.nextInt();
        this.run = scan.nextInt();
        this.swim = scan.nextInt();

        this.runTimes = new int[this.n];
        this.swimTimes = new int[this.n];
        for (int i = 0; i < this.n; i++) {
            this.runTimes[i] = scan.nextInt();
            this.swimTimes[i] = scan.nextInt();
        }
    }

    public int findBestTime() {
        List<Athlete> sortByDifference = new ArrayList<>();

        for (int i = 0; i < this.n; i++) {
            Athlete a = new Athlete(i, this.runTimes[i], this.swimTimes[i]);
            sortByDifference.add(a);
        }

        // Sort all the athletes by ascending order of difference in run time and swim time.
        // This is done because if person i is selected as a runner, and person j is selected
        // as a swimmer. Then a[i] − b[i] ≤ a[j] − b[j].
        sortByDifference.sort(new Comparator<Athlete>() {
            @Override
            public int compare(Athlete a1, Athlete a2) {
                return a1.difference - a2.difference;
            }
        });

        // PriorityQueue to store runners in descending order of run times.
        PriorityQueue<Athlete> runners = new PriorityQueue<>(new Comparator<Athlete>() {
            @Override
            public int compare(Athlete a1, Athlete a2) {
                return a2.runTime - a1.runTime;
            }
        });

        // HashSet to store swimmers in descending order of swim times.
        HashSet<Athlete> swimmers = new HashSet<>();

        int result = 0;

        ArrayList<Athlete> sortBySwim = new ArrayList<>(sortByDifference);

        // Runner PriorityQueue initially holds x amount of people.
        for (int i = 0; i < this.run; i++) {
            Athlete curr = sortBySwim.remove(0);
            runners.add(curr);
            result += curr.runTime;
        }

        sortBySwim.sort(new Comparator<Athlete>() {
            @Override
            public int compare(Athlete a1, Athlete a2) {
                return a1.swimTime - a2.swimTime;
            }
        });

        // Swimmer HashSet initially holds y amount of people with
        // fastest swim times who are confirmed not runners.
        for (int i = 0; i < this.swim; i++) {
            Athlete curr = sortBySwim.remove(0);
            swimmers.add(curr);
            result += curr.swimTime;
        }

        // Examine each cut
        for (int i = this.run; i < this.n - this.swim; i++) {
            int temp = result;
            Athlete curr = sortByDifference.get(i);
            sortBySwim.remove(curr);

            // Update runner list
            if (curr.runTime < runners.peek().runTime) {
                temp -= runners.poll().runTime;
                temp += curr.runTime;
                runners.add(curr);
            }

            // Update swimmer list
            if (swimmers.contains(curr)) {
                temp -= curr.swimTime;
                swimmers.remove(curr);
                Athlete replacement = sortBySwim.remove(0);
                swimmers.add(replacement);
                temp += replacement.swimTime;
            }

            result = Math.min(result, temp);
        }

        return result;
    }

    public static void main(String[] args) {
        Main main = new Main();
        System.out.println(main.findBestTime());
    }
}